module.exports = {
    googleClientID: '760385045230-aok6u3eibnah9um6ovn2vg41h5hi4k70.apps.googleusercontent.com',
    googleClientSecret: 'vR97ZJTJXhlgJ5aYhx_0Bz_K',
    mongoURI: 'mongodb+srv://shaqshaw:Sh@qattack179345@claflinresearch-6wjbe.mongodb.net/test?retryWrites=true&w=majority',
    cookieKey: 'vghgvkhgvkhgfhkfhgj'
}