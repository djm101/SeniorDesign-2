# seniordesign
#Steps to test
#1. to run files -> npm run dev
#2. run in google -> http://localhost:5000/auth/google
#3. log in with google credentials
#4. see in command screen 
#5. see successful addition to mongodb -> (email: shaw_shaquille11@yahoo.com, password: Sh@qattack179345)
#6. see command line for log in data

